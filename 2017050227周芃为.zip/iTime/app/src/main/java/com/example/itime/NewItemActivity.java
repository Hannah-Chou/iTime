package com.example.itime;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;


import com.lzy.imagepicker.view.FolderPopUpWindow;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import static com.example.itime.ImageUtils.ACTIVITY_RESULT_ALBUM;
import static com.example.itime.ImageUtils.ACTIVITY_RESULT_CAMERA;
import static com.example.itime.MainActivity.listTime;

public class NewItemActivity extends  AppCompatActivity implements DatePicker.OnDateChangedListener,TimePicker.OnTimeChangedListener{


    public final static int NEW_ITEM_OK=104,EDIT_ITEM_OK=105;

    private int year, month, day, hour, minute,position,imageID;
    private StringBuffer date, time;
    private Button buttonDate,buttonImage,buttonPeriod;
    private FragmentManager manager;
    private FragmentTransaction transaction;
    private EditText editTextTitle,editTextDescription;
    private ImageView image;
    private ImageButton buttonBack,buttonOk;
    private ImageUtils imageUtils = null;
    private String dateAll,dateNowAll,start,end,str;
    Intent intent;
    private long distance;
    private FrameLayout title;
    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        setContentView(R.layout.activity_new_item);
        getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE,      // 注意顺序
                R.layout.item_new_title_layout);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        intent=getIntent();

        title=this.findViewById(R.id.new_item_frameLayout);
        editTextTitle=this.findViewById(R.id.edit_text_title);
        editTextDescription=this.findViewById(R.id.edit_text_description);
        image=this.findViewById((R.id.image_view_background));
        buttonBack=this.findViewById(R.id.image_button_back);
        buttonOk=this.findViewById(R.id.image_button_ok);
        buttonDate=this.findViewById(R.id.button_date);
        buttonImage=this.findViewById(R.id.button_imagine);
        buttonPeriod=this.findViewById(R.id.button_period);
        //设置初始值
        if(MainActivity.color!=0) {
            image.setBackgroundColor(MainActivity.color);
        }
        editTextTitle.setText(intent.getStringExtra("title"));
        editTextDescription.setText(intent.getStringExtra("description"));

        position=intent.getIntExtra("position",-1);
        if(position!=-1){

            Time item=listTime.get(position);
            editTextTitle.setText(item.getTitle());
            editTextDescription.setText(item.getDescription());
            buttonDate.setText(item.getDate()+item.getTime());
            image.setBackgroundResource(item.getImageId());
            imageID=item.getImageId();
            buttonDate.setText(listTime.get(position).getDate()+ listTime.get(position).getTime());
        }
        else {
            buttonDate.setText(intent.getStringExtra("date&time"));
            editTextTitle.setText(intent.getStringExtra("title"));
            editTextDescription.setText(intent.getStringExtra("description"));
        }
        date = new StringBuffer();
        time = new StringBuffer();

        imageUtils = new ImageUtils(NewItemActivity.this);


        buttonImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chooseDialog();
            }
        });
        buttonDate =this.findViewById(R.id.button_date);
        buttonDate.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                initDateTime();
                AlertDialog.Builder builder = new AlertDialog.Builder(NewItemActivity.this);
                builder.setPositiveButton("设置", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (date.length() > 0) { //清除上次记录的日期
                            date.delete(0, date.length());
                        }
                        AlertDialog.Builder builder2 = new AlertDialog.Builder(NewItemActivity.this);
                        builder2.setPositiveButton("设置", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (time.length() > 0) { //清除上次记录的日期
                                    time.delete(0, time.length());
                                }
                                dialog.dismiss();
                            }
                        });
                        builder2.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        AlertDialog dialog2 = builder2.create();
                        View dialogView2 = View.inflate(NewItemActivity.this, R.layout.dialog_time, null);
                        TimePicker timePicker = (TimePicker) dialogView2.findViewById(R.id.timePicker);
                        timePicker.setCurrentHour(hour);
                        timePicker.setCurrentMinute(minute);
                        timePicker.setIs24HourView(true); //设置24小时制
                        timePicker.setOnTimeChangedListener(NewItemActivity.this);
                        dialog2.setTitle("设置时间");
                        dialog2.setView(dialogView2);
                        dialog2.show();
                        buttonDate.setText(String.valueOf(year)+"年"+String.valueOf(month)+"月"+(day)+"日"+String.valueOf(hour)+"时"+String.valueOf(minute)+"分");

                        dialog.dismiss();
                    }
                });
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                final AlertDialog dialog = builder.create();
                View dialogView = View.inflate(NewItemActivity.this, R.layout.dialog_date, null);
                final DatePicker datePicker = (DatePicker) dialogView.findViewById(R.id.datePicker);

                dialog.setTitle("设置日期");
                dialog.setView(dialogView);
                dialog.show();
                //初始化日期监听事件
                datePicker.init(year, month - 1, day, NewItemActivity.this);//获取当前年月
                return true;
                }
         });
        end=buttonDate.getText().toString();

        buttonPeriod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                actionAlertDialog();
            }
        });
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        buttonOk.setOnClickListener((new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    distance=getCount(buttonDate.getText().toString());

                    if(position!=-1){
                        Time item = listTime.get(position);
                        Time oldTime=item;
                        if(distance>0){
                            item.setDay(distance/(24*60*60*1000));
                            item.setDdl_kind("还剩");
                        }
                        else{
                            item.setDay(-distance/(24*60*60*1000));
                            item.setDdl_kind("已经");
                        }
                        item.setTitle(editTextTitle.getText().toString());
                        item.setDate(buttonDate.getText().toString().substring(0,buttonDate.getText().toString().indexOf("日")+ 1));
                        item.setTime(buttonDate.getText().toString().substring(buttonDate.getText().toString().indexOf("日")+ 1));
                        item.setDescription(editTextDescription.getText().toString());
                        item.setImageId(imageID);
                        listTime.set(position, item);
                        intent.putExtra("position",position);
                        setResult(RESULT_OK,intent);
                        finish();
                    }
                    else{

                        Time item=new Time(editTextTitle.getText().toString(),String.valueOf(year)+'年'+String.valueOf(month)+'月'+String.valueOf(day)+'日',String.valueOf(hour)+'时'+String.valueOf(minute)+'分',editTextDescription.getText().toString(),imageID);
                        if(distance>0){
                            item.setDay(distance/(24*60*60*1000));
                            item.setDdl_kind("还剩");
                        }
                        else{
                            item.setDay(-distance/(24*60*60*1000));
                            item.setDdl_kind("已经");
                        }
                        listTime.add(item);
                        setResult(RESULT_OK,intent);
                        finish();
                    }

                }

            }));



        }


    private void initDateTime() {
        Calendar calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH) + 1;
        day = calendar.get(Calendar.DAY_OF_MONTH);
        hour = calendar.get(Calendar.HOUR);
        minute = calendar.get(Calendar.MINUTE);
    }

    @Override
    public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
        this.year = year;
        this.month = monthOfYear+1;
        this.day = dayOfMonth;
    }


    @Override
    public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
        this.hour = hourOfDay;
        this.minute = minute;
    }

    private void chooseDialog() {
        new AlertDialog.Builder(this)//
                .setTitle("选择图片")//

                .setNegativeButton("相册", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        int[] picture={R.drawable.a1,R.drawable.a2,R.drawable.a3,R.drawable.a4,R.drawable.a5,R.drawable.a6,R.drawable.a7,R.drawable.a8,R.drawable.a9,R.drawable.a10,R.drawable.a11,R.drawable.a12};
                        int radom = (int) (Math.random() * picture.length);
                        imageID=picture[radom];
                        image.setBackgroundResource(imageID);
                        //title.setBackgroundResource(imageID);
                        //dialog.dismiss();
                        //imageUtils.byAlbum();

                    }
                })

                .setPositiveButton("拍照", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();
                        String status = Environment.getExternalStorageState();
                        if (status.equals(Environment.MEDIA_MOUNTED)) {// 判断是否存在SD卡
                            imageUtils.byCamera();
                        }
                    }
                }).show();

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        switch (requestCode) {
            case ACTIVITY_RESULT_CAMERA: // 拍照
                try {
                    if (resultCode == -1) {
                        imageUtils.cutImageByCamera();
                    } else {
                        // 因为在无任何操作返回时，系统依然会创建一个文件，这里就是删除那个产生的文件
                        if (imageUtils.picFile != null) {
                            imageUtils.picFile.delete();
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case ACTIVITY_RESULT_ALBUM:
                try {
                    if (resultCode == -1) {
                        Bitmap bm_icon = imageUtils.decodeBitmap();
                        if (bm_icon != null) {
                            image.setImageBitmap(bm_icon);
                        }
                    } else {
                        // 因为在无任何操作返回时，系统依然会创建一个文件，这里就是删除那个产生的文件
                        if (imageUtils.picFile != null) {
                            imageUtils.picFile.delete();
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case MainActivity.NEW_ITEM: {

                break;
            }
            case ItemInformationActivity.EDIT_ITEM:{

               break;
            }

        }
    }
    @Override

    public boolean onOptionsItemSelected(MenuItem item)
    {
        // TODO Auto-generated method stub
        if(item.getItemId() == android.R.id.home)
        {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public long getCount(String end){

        long distance=1000000;
        try{
            Calendar calendar = Calendar.getInstance();
            long timeMillis_now=calendar.getTimeInMillis();
            calendar.setTime(new SimpleDateFormat("yyyy年MM月dd日HH时mm分").parse(end));
            long timeMillis_set=calendar.getTimeInMillis();
            distance=timeMillis_set-timeMillis_now;
        }catch(ParseException e){
            e.printStackTrace();
        }
        return distance;
    }
    protected void actionAlertDialog(){
        String[] list=
                new String[]{"week","month","year","custom"};
        AlertDialog.Builder builder;
        AlertDialog alertDialog;

        LayoutInflater inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.period_view, (ViewGroup)findViewById(R.id.layout_myview));
        ListView myListView = (ListView) layout.findViewById(R.id.mylistview);
        ArrayAdapter<String> stringArrayAdapter=new ArrayAdapter<String>(
                this,android.R.layout.simple_list_item_1, list);
        myListView.setAdapter(stringArrayAdapter);
        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            }
        });
        builder = new AlertDialog.Builder(this);
        builder.setView(layout);
        alertDialog = builder.create();
        alertDialog.show();

    }

}
