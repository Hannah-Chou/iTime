package com.example.itime;

public class Time {
    private String title;
    private String date;
    private String time;
    private String description;
    private int imageId;
    private String ddl_kind;
    private long distance,day;

    public Time(String title, String date, String time, String description , int imageId) {
        this.title = title;
        this.date = date;
        this.time = time;
        this.description=description;
        this.imageId = imageId;
    }


    public long getDay() {
        return day;
    }

    public void setDay(long day) {
        this.day = day;
    }

    public String getDdl_kind() {
        return ddl_kind;
    }

    public void setDdl_kind(String ddl_kind) {
        this.ddl_kind = ddl_kind;
    }

    public void setDistance(long distance) {
        this.distance = distance;
    }

    public long getDistance() {
        return distance;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String descriptopn) {
        this.description = description;
    }

}
