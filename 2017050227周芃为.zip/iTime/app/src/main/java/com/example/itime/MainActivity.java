package com.example.itime;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.PaintDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.os.Bundle;

import com.example.itime.Time;
import com.example.itime.ui.home.HomeFragment;
import com.example.itime.ui.home.HomeViewModel;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.graphics.Color;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    public static final int CHECK_ITEM=101;
    public static final int NEW_ITEM=102;
    private AppBarConfiguration mAppBarConfiguration;
    FileDataSource fileDataSource ;
    private MyListView list;
    private FloatingActionButton button_new;
    public static TimeArrayAdapter adapter ;
    public static ArrayList<com.example.itime.Time> listTime;
    private Toolbar toolbar;
    CollapsingToolbarLayout collapsingToolbarLayout ;
    public static int color=0;
    private long distance;
    private ImageView imageViewMain;
    private LinearLayout headerMain;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        headerMain=this.findViewById(R.id.header_main);
        final DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        NavigationView navHome=findViewById(R.id.nav_home);
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow,
                R.id.nav_tools, R.id.nav_share, R.id.nav_send)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);


        imageViewMain=this.findViewById(R.id.image_view_title_main);

        button_new = this.findViewById((R.id.button_new_item));
        final ImageView imageViewTitle=this.findViewById(R.id.image_view_title_main);
        collapsingToolbarLayout = (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar_layout);
        ImageView first_item=this.findViewById(R.id.image_view_title_main);
        navigationView.setNavigationItemSelectedListener((new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_tools: {
                        drawer.closeDrawer(GravityCompat.START);
                        View view_d = getLayoutInflater().inflate(R.layout.color_set_dialog_layout, null);
                        final MyDialog mMyDialog = new MyDialog(MainActivity.this);
                        mMyDialog.setCancelable(true);

                        mMyDialog.show();
                        mMyDialog.setClickListener(new MyDialog.ClickListenerInterface() {
                            @SuppressLint("ResourceAsColor")
                            @Override
                            public void doConfirm() {
                                color=mMyDialog.mColor;
                                toolbar.setBackgroundColor(color);
                                button_new.setBackgroundTintList(ColorStateList.valueOf(color));
                                imageViewTitle.setBackgroundColor(color);
                               // headerMain.setBackgroundColor(color);
                                mMyDialog.dismiss();
                            }

                            @Override
                            public void doCancel() {
                                mMyDialog.dismiss();
                            }
                        });

                    }
                }
                return true;
            }
        }));

        list = (MyListView) this.findViewById(R.id.time_list);
        init();
        adapter = new TimeArrayAdapter(this, R.layout.list_time_item, listTime);
        list.setAdapter(adapter);


        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent = new Intent();
                intent.putExtra("position",position);
                intent.setClass(MainActivity.this, ItemInformationActivity.class);
                startActivityForResult(intent, CHECK_ITEM);
            }
        });

        button_new.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NewItemActivity.class);

                intent.putExtra("title","生日，节日，考试...");
                intent.putExtra("description","笔记，目标，座右铭...");
                intent.putExtra("date&time","长按以选择日期和时间");

                startActivityForResult(intent, NEW_ITEM);
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    void init() {
        fileDataSource = new FileDataSource(this);
        listTime = fileDataSource.load();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==NEW_ITEM) {
            if (resultCode == RESULT_OK) {
                adapter.notifyDataSetChanged();
                list.setAdapter(adapter);
            }
        }
        else if(requestCode==CHECK_ITEM) {
            if(resultCode==ItemInformationActivity.RESULT_BACK){
                adapter.notifyDataSetChanged();
                list.setAdapter(adapter);
            }
            else if(resultCode==ItemInformationActivity.DELETE_ITEM){
                int position =getIntent().getIntExtra("position",0);
                listTime.remove(position);
                adapter.notifyDataSetChanged();
                list.setAdapter(adapter);
            }
        }
    }
    protected void onDestroy() {
        super.onDestroy();
        fileDataSource.save();
    }
    public class TimeArrayAdapter extends ArrayAdapter<Time>
    {
        private  int resourceId;
        public TimeArrayAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull List<Time> objects) {

            super(context,resource,objects);
            resourceId=resource;
        }

        @NonNull
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater mInflater= LayoutInflater.from(this.getContext());
            View item = mInflater.inflate(this.resourceId,null);

            ImageView img = (ImageView)item.findViewById(R.id.imagine_view);
            TextView title = (TextView)item.findViewById(R.id.text_view_title);
            TextView date = (TextView)item.findViewById(R.id.text_view_date);
            TextView textViewDistance = (TextView)item.findViewById(R.id.text_view_count);
            TextView textViewStr = (TextView)item.findViewById(R.id.text_view_str);

            Time time_item= this.getItem(position);
            img.setImageResource(time_item.getImageId());
            title.setText(time_item.getTitle());
            date.setText(time_item.getDate());
            textViewDistance.setText(time_item.getDay()+"天");
            textViewStr.setText(time_item.getDdl_kind());
            return item;
        }
    }
}
