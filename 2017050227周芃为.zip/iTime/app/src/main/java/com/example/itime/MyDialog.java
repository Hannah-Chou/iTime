package com.example.itime;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.PaintDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.content.DialogInterface.OnClickListener;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MyDialog extends Dialog {
    Context context;
    public int mColor;
    private ClickListenerInterface clickListenerInterface;
    private SeekBar mSbColor;
    private ColorPickGradient mColorPickGradient;
    public interface ClickListenerInterface {
       public void doConfirm();

       public void doCancel();
    }

    public MyDialog(Context context) {
               super(context, R.style.DialogTheme);
               this.context = context;

             }

    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);

        init();
    }

    public void init(){
        LayoutInflater inflater=LayoutInflater.from(context);
        View view=inflater.inflate(R.layout.color_set_dialog_layout,null);
        setContentView(view);
        mSbColor=view.findViewById(R.id.seek_bar);
        mColorPickGradient=new ColorPickGradient();
        initColorBar();
        mSbColor.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float radio = (float)progress / mSbColor.getMax();
                mColor = mColorPickGradient.getColor(radio);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        Button buttonOk=(Button)view.findViewById(R.id.button_ok);
        Button buttonCancel=(Button)view.findViewById(R.id.button_cancel);
        buttonOk.setOnClickListener(new clickListener());
        buttonCancel.setOnClickListener(new clickListener());
        Window dialogWindow = getWindow();
         WindowManager.LayoutParams lp = dialogWindow.getAttributes();
         DisplayMetrics d = context.getResources().getDisplayMetrics(); // 获取屏幕宽、高用
         lp.width = (int) (d.widthPixels * 0.8); // 高度设置为屏幕的0.6
         dialogWindow.setAttributes(lp);
    }

    private void initColorBar(){
        ShapeDrawable.ShaderFactory shaderFactory = new ShapeDrawable.ShaderFactory() {
            @Override
            public Shader resize(int width, int height) {
                LinearGradient linearGradient = new LinearGradient(0, 0, width, height,
                        ColorPickGradient.PICKCOLORBAR_COLORS, ColorPickGradient.PICKCOLORBAR_POSITIONS, Shader.TileMode.REPEAT);
                return linearGradient;
            }
        };
        PaintDrawable paint = new PaintDrawable();
        paint.setShape(new RectShape());
        paint.setCornerRadius(10);
        paint.setShaderFactory(shaderFactory);
        mSbColor.setProgressDrawable(paint);
    }

    public void setClickListener(ClickListenerInterface clickListenerInterface){
        this.clickListenerInterface=clickListenerInterface;
    }

    private class clickListener implements View.OnClickListener{

        @Override
        public void onClick(View view) {
            int id= view.getId();
            switch(id){
                case R.id.button_ok:
                    clickListenerInterface.doConfirm();
                    break;
                case R.id.button_cancel:
                    clickListenerInterface.doCancel();
                    break;
            }

        }
    }
}
