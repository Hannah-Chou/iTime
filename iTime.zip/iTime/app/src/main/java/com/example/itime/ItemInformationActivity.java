package com.example.itime;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import static com.example.itime.MainActivity.adapter;
import static com.example.itime.MainActivity.listTime;

public class ItemInformationActivity extends AppCompatActivity {

    public final static int EDIT_ITEM = 103, DELETE_ITEM = 104, RESULT_BACK = 105;
    private int position;
    private ImageView imageView;
    private TextView dateTextView, titleTextView;
    private ImageButton imageButtonBack, imageButtonDelete, imageButtonEdit;
    private long day, hour, minute, second, counter, distance;

    private CountDownTimer countDownTimer;
    Intent intent;
    private Thread thread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);

        setContentView(R.layout.activity_item_information);

        getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE,      // 注意顺序
                R.layout.item_information_title_layout);

        intent = getIntent();

        imageView = this.findViewById(R.id.imageViewItem);
        titleTextView = this.findViewById(R.id.text_view_title1);
        dateTextView = this.findViewById(R.id.text_view_date1);
        imageButtonBack = this.findViewById((R.id.image_button_back));
        imageButtonEdit = this.findViewById(R.id.image_button_edit);
        imageButtonDelete = this.findViewById(R.id.image_button_delete);
        getItem();

        imageButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_BACK, intent);

                finish();
            }
        });
        imageButtonEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ItemInformationActivity.this, NewItemActivity.class);

                intent.putExtra("position", position);
                startActivityForResult(intent, EDIT_ITEM);

            }
        });
        imageButtonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listTime.remove(position);
                setResult(RESULT_BACK,intent);
                finish();
            }
        });
    }

    public void getItem() {

        position = intent.getIntExtra("position", 0);
        final Time item = listTime.get(position);
        imageView.setBackgroundResource(item.getImageId());
        titleTextView.setText(item.getTitle());
        String end = item.getDate() + item.getTime();
        distance = getCount(end);
        if (distance > 0) {
            item.setDdl_kind("还剩");
            item.setDistance(distance);
            counter = listTime.get(position).getDistance();
            final handler handle = new handler(dateTextView);
            thread = new Thread() {
                public void run() {
                    do {
                        Message msg = handle.obtainMessage();
                        counter = counter - 1000;
                        day = counter / (24 * 60 * 60 * 1000);
                        hour = (counter - day * (1000 * 24 * 60 * 60)) / (1000 * 60 * 60);
                        minute = (counter - day * (1000 * 24 * 60 * 60) - hour * (1000 * 60 * 60)) / (1000 * 60);
                        second = (counter - day * (1000 * 24 * 60 * 60) - hour * (1000 * 60 * 60) - minute * (1000 * 60)) / 1000;
                        String time = listTime.get(position).getDate() + listTime.get(position).getTime() + '\n' + "还剩" + String.valueOf(day) + "天" + String.valueOf(hour) + "小时" + String.valueOf(minute) + "分" + String.valueOf(second) + "秒";
                        item.setDistance(counter);
                        item.setDay(day);
                        msg.obj = time;
                        handle.sendMessage(msg);
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } while (true);
                }
            };
            thread.start();
        } else {
            item.setDdl_kind("已经");
            item.setDistance(-distance);
            counter = listTime.get(position).getDistance();
            final handler handle = new handler(dateTextView);
            thread = new Thread() {
                public void run() {
                    do {
                        Message msg = handle.obtainMessage();
                        counter = counter + 1000;
                        day = counter / (24 * 60 * 60 * 1000);
                        hour = (counter - day * (1000 * 24 * 60 * 60)) / (1000 * 60 * 60);
                        minute = (counter - day * (1000 * 24 * 60 * 60) - hour * (1000 * 60 * 60)) / (1000 * 60);
                        second = (counter - day * (1000 * 24 * 60 * 60) - hour * (1000 * 60 * 60) - minute * (1000 * 60)) / 1000;
                        String time = listTime.get(position).getDate() + listTime.get(position).getTime() + '\n' + "已经" + String.valueOf(day) + "天" + String.valueOf(hour) + "小时" + String.valueOf(minute) + "分" + String.valueOf(second) + "秒";
                        item.setDistance(counter);
                        item.setDay(day);
                        msg.obj = time;
                        handle.sendMessage(msg);
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } while (true);
                }
            };
            thread.start();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            position = data.getIntExtra("position", 0);
            final Time item = listTime.get(position);
            imageView.setBackgroundResource(item.getImageId());
            titleTextView.setText(item.getTitle());
            String end = item.getDate() + item.getTime();
            distance = getCount(end);
            if (distance > 0) {
                item.setDdl_kind("还剩");
                item.setDistance(distance);
                counter = distance;
                final handler handle = new handler(dateTextView);
                thread = new Thread() {
                    public void run() {
                        do {
                            Message msg = handle.obtainMessage();
                            counter = counter - 1000;
                            day = counter / (24 * 60 * 60 * 1000);
                            hour = (counter - day * (1000 * 24 * 60 * 60)) / (1000 * 60 * 60);
                            minute = (counter - day * (1000 * 24 * 60 * 60) - hour * (1000 * 60 * 60)) / (1000 * 60);
                            second = (counter - day * (1000 * 24 * 60 * 60) - hour * (1000 * 60 * 60) - minute * (1000 * 60)) / 1000;
                            String time = listTime.get(position).getDate() + listTime.get(position).getTime() + '\n' + "还剩" + String.valueOf(day) + "天" + String.valueOf(hour) + "小时" + String.valueOf(minute) + "分" + String.valueOf(second) + "秒";
                            item.setDay(day);
                            msg.obj = time;
                            handle.sendMessage(msg);
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        } while (true);
                    }
                };
                thread.start();
            } else {
                item.setDdl_kind("已经");
                item.setDistance(-distance);
                counter = -distance;
                final handler handle = new handler(dateTextView);
                thread = new Thread() {
                    public void run() {
                        do {
                            Message msg = handle.obtainMessage();
                            counter = counter + 1000;
                            day = counter / (24 * 60 * 60 * 1000);
                            hour = (counter - day * (1000 * 24 * 60 * 60)) / (1000 * 60 * 60);
                            minute = (counter - day * (1000 * 24 * 60 * 60) - hour * (1000 * 60 * 60)) / (1000 * 60);
                            second = (counter - day * (1000 * 24 * 60 * 60) - hour * (1000 * 60 * 60) - minute * (1000 * 60)) / 1000;
                            String time = listTime.get(position).getDate() + listTime.get(position).getTime() + '\n' + "已经" + String.valueOf(day) + "天" + String.valueOf(hour) + "小时" + String.valueOf(minute) + "分" + String.valueOf(second) + "秒";
                            item.setDay(day);
                            msg.obj = time;
                            handle.sendMessage(msg);
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        } while (true);
                    }
                };
                thread.start();
            }
        }
    }

    public long getCount(String end) {

        long distance = 1000000;
        try {
            Calendar calendar = Calendar.getInstance();
            long timeMillis_now = calendar.getTimeInMillis();
            calendar.setTime(new SimpleDateFormat("yyyy年MM月dd日HH时mm分").parse(end));
            long timeMillis_set = calendar.getTimeInMillis();
            distance = timeMillis_set - timeMillis_now;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return distance;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (thread != null) {
            Thread dummy = thread;
            thread = null;
            dummy.interrupt();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (thread != null) {
            Thread dummy = thread;
            thread = null;
            dummy.interrupt();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (thread != null) {
            Thread dummy = thread;
            thread = null;
            dummy.interrupt();
        }
    }

    class handler extends Handler {
        TextView textViewCount;

        public handler(TextView textViewCount) {
            super();
            this.textViewCount = textViewCount;
        }

        public void handleMessage(Message msg) {
            String text = (String) msg.obj;
            textViewCount.setText(text);
        }
    }
}



